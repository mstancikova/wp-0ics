<?php
/**
 * Il file base di configurazione di WordPress.
 *
 * Questo file definisce le seguenti configurazioni: impostazioni MySQL,
 * Prefisso Tabella, Chiavi Segrete, Lingua di WordPress e ABSPATH.
 * E' possibile trovare ultetriori informazioni visitando la pagina: del
 * Codex {@link http://codex.wordpress.org/Editing_wp-config.php
 * Editing wp-config.php}. E' possibile ottenere le impostazioni per
 * MySQL dal proprio fornitore di hosting.
 *
 * Questo file viene utilizzato, durante l'installazione, dallo script
 * di creazione di wp-config.php. Non � necessario utilizzarlo solo via
 * web,� anche possibile copiare questo file in "wp-config.php" e
 * rimepire i valori corretti.
 *
 * @package WordPress
 */

// ** Impostazioni MySQL - E? possibile ottenere questoe informazioni
// ** dal proprio fornitore di hosting ** //
/** Il nome del database di WordPress */
define('DB_NAME', 'icscom_0icstest');

/** Nome utente del database MySQL */
define('DB_USER', 'icscom_web');

/** Password del database MySQL */
define('DB_PASSWORD', 'icscom_web');

/** Hostname MySQL  */
define('DB_HOST', 'www.0ics.com');

/** Charset del Database da utilizare nella creazione delle tabelle. */
define('DB_CHARSET', 'utf8');

/** Il tipo di Collazione del Database. Da non modificare se non si ha
idea di cosa sia. */
define('DB_COLLATE', '');

/**#@+
 * Chiavi Univoche di Autenticazione e di Salatura.
 *
 * Modificarle con frasi univoche differenti!
 * E' possibile generare tali chiavi utilizzando {@link https://api.wordpress.org/secret-key/1.1/salt/ servizio di chiavi-segrete di WordPress.org}
 * E' possibile cambiare queste chiavi in qualsiasi momento, per invalidare tuttii cookie esistenti. Ci� forzer� tutti gli utenti ad effettuare nuovamente il login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY',         '5gbxj-OQ&A7_uH, ttYH{wMv$4-}2o0GHkDe(lVQ/cQTWdZ`+|<;D/1CMG#*i?Ln');
define('SECURE_AUTH_KEY',  '~S8|Xxx96.iOmMI}mI7<-*zQ:C(a*@Mlq+0)dnQRH|.<f%0El^.@zfhA{37uA.~V');
define('LOGGED_IN_KEY',    'jlIOK[9SKqUQ|Cqf@VmOp*4|e:Alw0FIGc%=k?dx&>jW!2$^.iq3o^34{Wdx dFe');
define('NONCE_KEY',        '}E|+I+wWzI0 E&8f:*)I|W1==8I #pwKI3M^_VJEKt0d*>3[BX@P@o6Hw|07HhIt');
define('AUTH_SALT',        '&D <=]W+$|f3_~a)$/CGnDe|8p+zK*]|TQ*Ey{##H&c+: g<lxA6|?p10}l-<~<N');
define('SECURE_AUTH_SALT', '}2<h/ulcdMokiIj0qn%L#z4ENh_,vI9pWN1M,+|A(;(p2GJ$=A:qLqxJE|y0<R~s');
define('LOGGED_IN_SALT',   'rT|<MXkrAMQLkd9gO-|W(gr54 ,DPm9xl5RtzP,KQ-v|7oHIBzxCJ)jPzgk[ar+i');
define('NONCE_SALT',       'Vmy8<%o%0EtB<eK]00>5ZrgcdKd7+DJEeu,M1vjuP:7+67VWs>t$Eu85JKulq+rf');

/**#@-*/

/**
 * Prefisso Tabella del Database WordPress .
 *
 * E' possibile avere installazioni multiple su di un unico database if you give each a unique
 * fornendo a ciascuna installazione un prefisso univoco.
 * Solo numeri, lettere e sottolineatura!
 */
$table_prefix  = 'wp_0ics_';

/**
 * Per gli sviluppatori: modalit� di debug di WordPress.
 *
 * Modificare questa voce a TRUE per abilitare la visualizzazione degli avvisi
 * durante lo sviluppo.
 * E' fortemente raccomandato agli svilupaptori di temi e plugin di utilizare
 * WP_DEBUG all'interno dei loro ambienti di sviluppo.
 */
define('WP_DEBUG', false);

/* Finito, interrompere le modifiche! Buon blogging. */

/** Path assoluto alla directory di WordPress. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Imposta lle variabili di WordPress ed include i file. */
require_once(ABSPATH . 'wp-settings.php');
